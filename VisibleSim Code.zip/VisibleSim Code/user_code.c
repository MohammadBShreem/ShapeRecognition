#include <user_code.h>
#include <layer3_generic.h>
#include <microphone.h>
#include <speaker.h>
#include <light.h>
#include <abstraction.h>
#include <BB.h> // Include BB.h for network and utility functions
#include <stdio.h> // For printf function

// Define the colors
#define RED 1
#define YELLOW 2
#define GREEN 3
#define BLUE 4
#define BLACK 0

// Define the status enums
typedef enum __packed {WAITING, ACTIVE} Status;

// Initialize the status
Status status = WAITING;

// Variables to store the previous connection status of ports
bool previousConnectionStatus[NB_SERIAL_PORT];

// Function to get the color based on the port of the external block
uint8_t getColorForExternalBlock(uint8_t port) {
    switch (port) {
        case 0: return RED;     // External block connected via Port 0 -> RED
        case 1: return YELLOW;  // External block connected via Port 1 -> YELLOW
        case 2: return GREEN;   // External block connected via Port 2 -> GREEN
        case 3: return BLUE;    // External block connected via Port 3 -> BLUE
        default: return BLACK;  // Default -> BLACK
    }
}

// Function to check if a color is valid in the current position
bool isValidColor(uint8_t color, uint8_t x, uint8_t y) {
    // Check row and column
    for (uint8_t i = 0; i < 4; ++i) {
        if (getColor(x, i) == color || getColor(i, y) == color) {
            return false;
        }
    }

    // Check 2x2 subgrid
    uint8_t startX = (x / 2) * 2;
    uint8_t startY = (y / 2) * 2;
    for (uint8_t i = startX; i < startX + 2; ++i) {
        for (uint8_t j = startY; j < startY + 2; ++j) {
            if (getColor(i, j) == color) {
                return false;
            }
        }
    }

    return true;
}

// Function to propagate color to neighbors
void propagateColor(uint8_t color, uint8_t x, uint8_t y) {
    setColor(color);
    printf("Block at (%d, %d) set to color %d\n", x, y, color);

    // Check and propagate to neighbors
    for (uint8_t i = 0; i < NB_SERIAL_PORT; ++i) {
        if (is_connected(i)) {
            uint8_t neighborColor = getColorForExternalBlock(i);
            if (neighborColor != BLACK && isValidColor(neighborColor, x, y)) {
                setColor(neighborColor);
                printf("Neighbor at port %d set to color %d\n", i, neighborColor);
            }
        }
    }
}

// Initialization function
void BBinit() {
    status = ACTIVE; // Set the block to active
    printf("Block initialized. ID: %lu\n", get_id()); // Use %lu for uint32_t

    // Initialize the previous connection status
    for (uint8_t i = 0; i < NB_SERIAL_PORT; ++i) {
        previousConnectionStatus[i] = is_connected(i);
    }
    setColor(BLACK); // Default starting color
}

// Main loop function
void BBloop() {
    if (status == ACTIVE) {
        for (uint8_t i = 0; i < NB_SERIAL_PORT; ++i) {
            bool currentConnectionStatus = is_connected(i);

            // Check if the connection status of the port has changed
            if (currentConnectionStatus != previousConnectionStatus[i]) {
                if (currentConnectionStatus) {
                    // Determine the color based on the port of the external block
                    uint8_t color = getColorForExternalBlock(i);
                    if (color != BLACK && isValidColor(color, get_x(), get_y())) {
                        propagateColor(color, get_x(), get_y());
                    }
                }

                // Update the previous connection status
                previousConnectionStatus[i] = currentConnectionStatus;
            }
        }
    }
}